window.onload = init;

// Setting the game scene window size
var WIDTH = 800;
var HEIGHT = 600;

var VIEW_ANGLE = 45;
var ASPECT_RATIO = WIDTH / HEIGHT;
var NEAR_CLIPPING_PLANE = 0.1;
var FAR_CLIPPING_PLANE = 10000;

var renderer;
var scene;
var camera;

var stats;
var clock = new THREE.Clock();

// Initialising the controls for mouse movement and mouse interaction
var mouseOverCanvas;
var mouseDown;
var controls;

// Initialising the loader needed to load each object into the scene
var myColladaLoader;
// Hazard DAE object variables to add to array
var myDaeFile;
var myTrain;
var myEBox;
var myTyre;
var myPipe;
var myLamp;
var myMan;

// Initially used for identifying each object in the scene for further 
//		detail after object interactions, this is now assigned to load the 
//		file name due to .name being "undefined"
var eBoxName = 'Ebox';
var tyreName = 'Tyre';
var pipeName = 'Pipe';
var lampName = 'Lamp';
var manName = 'Man';

// Initialising the score and timer variables
var score = 0;
var time = 70;

// Adding vars to instantiate raycasting function
var raycaster = new THREE.Raycaster();
var mouse = new THREE.Vector2();

// Adding array to hold hazard for interaction
var objects = [];

// Setting up and initiating the camera, controls and scene view before objects and lighting is loaded
    function init()
    {

        renderer = new THREE.WebGLRenderer();
        renderer.setSize(WIDTH, HEIGHT);

        var docElement = document.getElementById('myDivContainer');
        docElement.appendChild(renderer.domElement);

        // Setting a 'sky blue' colour for background
        renderer.setClearColor("rgb(135,206,250)");

            renderer.domElement.onmouseover=function(e){
                mouseOverCanvas = true;
            }
            renderer.domElement.onmousemove=function(e){
                mouseOverCanvas = true;
            }
            renderer.domElement.onmouseout=function(e){
                mouseOverCanvas = false;
            }
            renderer.domElement.onmousedown=function(e){
                mouseDown = true;
            }
            renderer.domElement.onmouseup=function(e){
                mouseDown = false;
            }

        // Double click event for interacting with removable objects
        renderer.domElement.ondblclick=onDoubleClick;

        // Initiating the framerate stats window
        stats = new Stats();
        stats.domElement.style.position = 'absolute';
        stats.domElement.style.top = '0px';
        stats.domElement.style.zIndex = 100;
        docElement.appendChild( stats.domElement );

        // Creating the WebGL scene
        scene = new THREE.Scene();
        // Creating the WebGL camera
        camera = new THREE.PerspectiveCamera(VIEW_ANGLE, ASPECT_RATIO, NEAR_CLIPPING_PLANE, FAR_CLIPPING_PLANE);
        // Sets camera position
        camera.position.set(0, 5, 0);

        //Assigning the camera controls to the camera
        controls = new THREE.FirstPersonControls(camera, document.getElementById('myDivContainer'));
        controls.movementSpeed = 20; //was 10 - too slow
        controls.lookSpeed = 0.05;
        controls.activeLook = false;

        // Added listerner to check if mouse intercepts hazard objects
        renderer.domElement.addEventListener( 'mousemove', onDocumentMouseMove, false );

            // Method call to load the lights and objects now that scene is ready
            initScene();
            render();

    }

    function initScene()
    {

        // Adding two lights to the scene to brighten up the models
        var light = new THREE.DirectionalLight(0xffffff, 1.5);
        light.position.set(1, 1, 1);
        scene.add(light);

        var light2 = new THREE.DirectionalLight(0xffffff, 0.75);
        light2.position.set(-1, -0.5, -1);
        scene.add(light2);

         /** Adding the objects here **/

        // Object for RailWay.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/RailWay.DAE', function (collada)
            {
                var myDaeFile = collada.scene;
                /**	Setting the position here esnures that the
                        exported object's origin point (which is set
                        to the embedded 'cylinder') can serve as the
                        starting point for all objects spawned in the
                        scene as well as the camera for the player controller **/
                myDaeFile.position.x = 0;
                myDaeFile.position.y = 0;
                myDaeFile.position.z = 0;
                myDaeFile.rotation.y = 90 * Math.PI / 180;
                myDaeFile.scale.x = 2.5;
                myDaeFile.scale.y = 2;
                myDaeFile.scale.z = 3;
                myDaeFile.updateMatrix();

                myDaeFile.name = "ground";
                scene.add(myDaeFile);
            });

        // Object for Train.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/Train.DAE', function (collada)
            {
                var myTrain = collada.scene;
                myTrain.position.x = 18.435;
                myTrain.position.y = 1;
                myTrain.position.z = 50;
                myTrain.rotation.y = 270 * Math.PI / 180;
                myTrain.scale.x = 0.25;
                myTrain.scale.y = 0.1;
                myTrain.scale.z = 0.075;
                myTrain.updateMatrix();

                myTrain.name = "train";
                scene.add(myTrain);
                objects.push(myTrain);
            });

        // Object for Man.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/' + manName + '.DAE', function (collada)
            {
                var myMan = collada.scene;
                myMan.position.x = 25;
                myMan.position.y = -1.5;
                myMan.position.z = 50;
                myMan.rotation.y = 90 * Math.PI / 180;
                myMan.scale.x = 0.2;
                myMan.scale.y = 0.2;
                myMan.scale.z = 0.2;
                myMan.updateMatrix();

                myMan.name = "man";
                scene.add(myMan);
                objects.push(myMan);
            });

        // Object for Lamp.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/' + lampName + '.DAE', function (collada)
            {
                var myLamp = collada.scene;
                myLamp.position.x = 43;
                myLamp.position.y = -2;
                myLamp.position.z = 60;
                myLamp.rotation.y = 135 * Math.PI / 180;
                myLamp.scale.x = 0.5;
                myLamp.scale.y = 0.5;
                myLamp.scale.z = 0.5;
                myLamp.updateMatrix();

                myLamp.name = "lamp";
                scene.add(myLamp);
                objects.push(myLamp);
            });

        // Object for Pipe.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/' + pipeName + '.DAE', function (collada)
            {
                var myPipe = collada.scene;
                myPipe.position.x = 14.9;
                myPipe.position.y = -2.6;
                myPipe.position.z = -7.5;
                myPipe.rotation.y = 27 * Math.PI / 180;
                myPipe.scale.x = 0.05;
                myPipe.scale.y = 0.05;
                myPipe.scale.z = 0.05;
                myPipe.updateMatrix();

                myPipe.name = "pipe";
                scene.add(myPipe);
                objects.push(myPipe);
            });

        // Object for Tyre.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/' + tyreName + '.DAE', function (collada)
            {
                var myTyre = collada.scene;
                myTyre.position.x = 33.85;
                myTyre.position.y = -2.5;
                myTyre.position.z = 25.67;
                myTyre.rotation.z = 35 * Math.PI / 180;
                myTyre.scale.x = 0.1;
                myTyre.scale.y = 0.1;
                myTyre.scale.z = 0.1;
                myTyre.updateMatrix();

                myTyre.name = "tyre";
                scene.add(myTyre);
                objects.push(myTyre);
            });

        //Object for Ebox.DAE
        myColladaLoader = new THREE.ColladaLoader();
        myColladaLoader.options.convertUpAxis = true;
            myColladaLoader.load( 'DAEObjects/' + eBoxName + '.DAE', function (collada)
            {
                var myEBox = collada.scene;
                myEBox.position.x = -1;
                myEBox.position.y = 0;
                myEBox.position.z = 50;
                myEBox.rotation.y = 0 * Math.PI / 180;
                myEBox.scale.x = 0.1;
                myEBox.scale.y = 0.1;
                myEBox.scale.z = 0.1;
                myEBox.updateMatrix();

                myEBox.name = "ebox";
                scene.add(myEBox);
                objects.push(myEBox);
            });

    }

    // Double Click Mouse Event
    function onDoubleClick(event)
    {

        mouseDown = false;
        mouse.x = ( event.clientX / renderer.domElement.width ) * 2 - 1;
        mouse.y = - ( event.clientY / renderer.domElement.height ) * 2 + 1;

        raycaster.setFromCamera( mouse, camera );

        var intersects = raycaster.intersectObjects( objects, true );

            if (intersects.length > 0)
            {
                intersects[0].object.material.visible = false;
                score += 1;
                    // 6 Total objects that are hazards
                    if(score == 6)
                    {
                        clock.stop();
                    }
            }

    }

    function onDocumentMouseMove ( event )
    {

    }

    function render()
    {
        controls.activeLook = false;
            if(mouseOverCanvas)
            {
                controls.activeLook = true;
                    if(mouseDown)
                    {
                        //controls.activeLook = true;
                    }
            }

        var deltaTime = clock.getDelta();
        controls.update(deltaTime);

        // Adding the score text and variable to the div containter in 'index.html'
        document.getElementById("ScoreTable").innerHTML = " SCORE: " + score;
        var newTime = (time - clock.getElapsedTime());

        if (newTime <= 0) {
            newTime = 0;
        }
        // Adding the timer text, variable and instructions to the respective div containters in 'index.html'
        document.getElementById("TimeTable").innerHTML = " TIME LEFT: " + Math.floor(newTime);
        document.getElementById("Instructions").innerHTML = "SPOT ALL THE HAZARDS<br>Please use 'W','A','S','D' to explore the scene<br>To Identify a hazard, double click on the icon";

        renderer.render(scene, camera);
        // Updates the fps rate stats
        stats.update();
        requestAnimationFrame(render);

    }