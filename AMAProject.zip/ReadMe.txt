The Following HTML file was the result of a 2-Week project 
regarding Advanced Multimedia Authoring. The game that I developed
utilised a javascript environment for the user to explore and spot
the hazards surrounding a railway scene, of which the environment 
and objects were all created by me.
These objects were made in 3DS Max and exported to the browser in
the filetype OpenCollada (.DAE). 